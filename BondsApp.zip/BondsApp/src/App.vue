<template>
  <div class="container">
    <h2 class="title">Стоимость акций компаний</h2>
    <Lab />
  </div>
</template>

<script setup>
import Lab from './components/Lab.vue'

</script>

